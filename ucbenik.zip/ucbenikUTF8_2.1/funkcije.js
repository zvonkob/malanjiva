function okno_primer(url)
{
   parametri = "width=800,height=600,scrollbars=1,resizable=1,menubar=1,status=1";
   ime = "primer";
   window.open(url, ime, parametri);
}

function okno_tabela(url)
{
   parametri = "width=800,height=600,scrollbars=1,resizable=1,menubar=1,status=1";
   ime = "tabela";
   window.open(url, ime, parametri);
}
